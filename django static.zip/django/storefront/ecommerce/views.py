from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse

# Create your views here.
def homeView(request):
    template=loader.get_template('index.html')
    return HttpResponse (template.render())    

def contactView(request):
    template=loader.get_template('contact.html')
    return HttpResponse (template.render())  

def chackoutView(request):
    template=loader.get_template('chackout.html')
    return HttpResponse (template.render())  


def cartView(request):
    template=loader.get_template('cart.html')
    return HttpResponse (template.render())  

def e404View(request):
    template=loader.get_template('404.html')
    return HttpResponse (template.render())  

def shopView(request):
    template=loader.get_template('shop.html')
    return HttpResponse (template.render()) 

def shopdetailView(request):
    template=loader.get_template('shop-detail.html')
    return HttpResponse (template.render()) 

def testimonialView(request):
    template=loader.get_template('testimonial.html')
    return HttpResponse (template.render()) 